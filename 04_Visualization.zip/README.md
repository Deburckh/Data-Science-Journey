# Data Science Job Salaries
## by Dennis


## Dataset

> I used my own dataset, which I found on Kaggle https://www.kaggle.com/datasets/ruchi798/data-science-job-salaries. The data primarily shows the salaries of employees who work in data science related jobs, comparing them for different experience levels, countries, company sizes, etc. In detail documentation can be found on the Kaggle website.


## Summary of Findings

> The main take aways of the dataset are that more experienced employees (senior, expert) who work in medium (50-250) or large (>250) sized companies earn the most amount of money. That trend is pretty consistent accross different countries and is not impacted by the ratio of remote work done by the employee.


## Key Insights for Presentation

> One of the main aspects I want to show is the correlation between salary and experience level, being the most important factor in my opinion, I will use my bivariate plot for this. Another interesting aspect I want to show is the correlation between salary and company size, for which I will also use my bivariate plot. For my third plot I want to use a multivariate plot showing salary, experience level and company size, using a faceted plot. My final plot shows salary, remote ratio and company size using a colored scatter plot.